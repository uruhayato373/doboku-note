---
taskId: sample-001
exam: civil-1        # civil-1 | civil-2
format: current2     # current2 | legacy3 | yosou
status: needs-review # draft | needs-review | needs-rework | revised | verified | approved
questionSource: inputs/questions/{name}.md
projectSource: inputs/user-experience/project-input.md
unknowns: []         # 未確認事実があればここに列挙
generatedAt: YYYY-MM-DD
---

<!--
答案本文だけを各見出しの直下に書く。解説・注釈・メタコメントは書かない。
- current2 形式: ## 設問(1) と ## 設問(2)
- legacy3 形式: ## 設問(1) / ## 設問(2) / ## 設問(3)
- yosou 形式: ## 記述例
本人入力に無い事実は 〇〇（全角）で置き、frontmatter の unknowns に載せる。
-->

## 設問(1) 特に留意した技術的課題

（ここに答案本文）

## 設問(2) 検討した項目・採用した処置・評価

（ここに答案本文）
