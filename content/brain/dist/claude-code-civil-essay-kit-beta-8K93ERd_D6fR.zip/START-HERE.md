# はじめにお読みください（START-HERE）

> 同じ内容を `START-HERE.pdf` でも同梱しています。読みやすい方をお使いください。

## このキットは何か

**Claude Code で、あなた自身の工事経験から施工経験記述の答案を設計・検証するための道具一式**です。

- 対象試験: 1級・2級土木施工管理技士 第2次検定「問題1 施工経験記述」
- 中身: Claude Code 用スキル1本／エージェント2本／入力シート・答案・レビューのテンプレート／字数・必須項目・プレースホルダを検査するローカルスクリプト／架空のサンプル一式

**これは「完成答案を売る商品」ではありません。** AI に丸投げで作文させるのではなく、
あなたが実際に経験した工事を、設問要求と字数制約に沿って構造化する作業環境です。

## 動作に必要なもの

- Claude Code（CLI）が使えること
- Node.js（検査スクリプト実行用。`node --version` で確認）
- あなた自身が経験した工事の事実

## 使い方（サンプルで一巡）

1. このフォルダで Claude Code を起動する。
2. まずサンプルで動きを確認する:
   ```
   node .claude/skills/draft-civil-experience-essay/scripts/check-answer-length.mjs examples/sample-draft.md --strict
   node .claude/skills/draft-civil-experience-essay/scripts/check-required-fields.mjs examples/sample-project-input.md --strict
   node .claude/skills/draft-civil-experience-essay/scripts/check-placeholders.mjs examples/sample-draft.md --strict
   ```
3. 本番は次の手順:
   - `.claude/skills/draft-civil-experience-essay/assets/project-input.template.md` を
     `inputs/user-experience/project-input.md` にコピーして、**あなたの工事**を記入する。
   - 対象年度の問題文を `inputs/questions/` に置く。
   - Claude Code に「施工経験記述の答案を設計して」と伝える。スキルが起動し、
     設問分解 → 不足情報の UNKNOWN 提示 → 骨子 → 初稿 → 独立レビュー → 字数検査 まで進む。
   - `outputs/approved/` へのコピー（承認）は**あなた自身が**行う。

## 大切な約束（安全境界）

- 本キットは、あなたが**経験していない工事を創作しません**。
- 工期・施工量・立場・規格値などの現場固有の数値を**推測で埋めません**。分からない箇所は `〇〇` と `UNKNOWN` で残ります。
- 本キットは「採点者」「添削者」ではなく、**合格を保証しません**。
- 会社・顧客の機密情報は入力しないでください（匿名化してから使う）。

## Windows / macOS の違い

手順は共通ですが、コマンドの見た目が少し異なります。

- **パス区切り**: 本書の例は `/`（スラッシュ）表記です。Windows でもこのキット内の
  相対パス（`examples/...`）はそのまま動きます。
- **Node.js の確認**: どちらも `node --version` で確認します。未インストールなら
  [Node.js 公式](https://nodejs.org/) からインストールしてください。
- **フォルダを開く**: Claude Code を、このキットを展開したフォルダで起動します。
  Windows はエクスプローラ、macOS は Finder で場所を確認してから起動してください。
- **文字コード**: 入力ファイルは UTF-8 で保存してください（文字化け防止）。

このキットの検査スクリプトは Node.js の標準機能だけで動き、追加インストール（npm install）は不要です。

## サポート範囲

- 対象: キットの導入とサンプル操作の不具合。
- 対象外: あなたの答案内容の個別添削、合否判定、試験の最新制度に関する助言。

詳細な免責は `DISCLAIMER.txt`、ライセンスは `LICENSE.txt` を参照してください。
