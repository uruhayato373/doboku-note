#!/usr/bin/env node
// 施工経験記述ドラフトの答案字数を、級×形式の解答欄しきい値で機械チェックする。
// 決定論的処理（判定はここ、修正は Generator、評価は Evaluator）。
//
// 使い方:
//   node check-answer-length.mjs outputs/drafts/{task-id}.md [--json] [--strict]
//     --json   : 機械可読 JSON を出力
//     --strict : 要圧縮(over)以上が1件でもあれば exit 1（ゲート用）
//
// ドラフト形式（assets/answer.template.md 準拠）:
//   frontmatter に exam(civil-1|civil-2) と format(current2|legacy3|yosou)。
//   答案本文は「## 設問(1) ...」「## 設問(2) ...」「## 設問(3) ...」または
//   「## 記述例」見出しの直下に置く。解説・注釈は書かない。

import { readFileSync, existsSync } from 'node:fs';

// --- しきい値の真実源（公開試験仕様・確認日 2026-06-02）--------------------
// 1級=罫線約25字/行。2級=1項目あたり約250字の通説目安（公式字数規定なし）。
// 年度で解答欄が変わり得るため、購入者は対象年度の実物で最終確認する（references/*.md 参照）。
const LIMITS = {
  'civil-1': {
    current2_q1: 200, current2_q2: 200,
    legacy3_q1: 225, legacy3_q2: 275, legacy3_q3: 175,
    yosou: 200,
  },
  'civil-2': {
    current2_q1: 250, current2_q2: 250,
    legacy3_q1: 250, legacy3_q2: 250, legacy3_q3: 250,
    yosou: 250,
  },
};
const TOL = 0.1;   // +10% 以内は borderline（1行字数の幅で収まり得る）
const SEVERE = 1.3; // ×1.3 超は解答欄に物理的に収まらない

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const strict = args.includes('--strict');
const inputs = args.filter((a) => !a.startsWith('--'));

if (inputs.length === 0) {
  console.error('usage: node check-answer-length.mjs outputs/drafts/{task-id}.md [--json] [--strict]');
  process.exit(2);
}

function parseFrontmatter(txt) {
  const fm = { exam: null, format: null };
  if (!txt.startsWith('---')) return { fm, body: txt };
  const end = txt.indexOf('\n---', 3);
  if (end === -1) return { fm, body: txt };
  const head = txt.slice(3, end);
  for (const line of head.split(/\r?\n/)) {
    const m = line.match(/^\s*(exam|format)\s*:\s*(.+?)\s*$/);
    if (m) fm[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
  const body = txt.slice(txt.indexOf('\n', end + 1) + 1);
  return { fm, body };
}

// markdown 装飾・タグ・空白を除いた実文字数（プレースホルダ 〇 は算入）
function countChars(s) {
  const clean = s
    .replace(/<[^>]+>/g, '')
    .replace(/[`*]/g, '')
    .replace(/\s/g, '');
  return [...clean].length;
}

// 「## 設問(N) ...」「## 記述例」見出しを検出。答案本文は次見出しまで。
function extractAnswers(body) {
  const lines = body.split(/\r?\n/);
  const out = [];
  let cur = null;
  for (const raw of lines) {
    const s = raw.trim();
    const h = s.match(/^#{1,4}\s+/);
    if (h) {
      if (cur) out.push(cur);
      let cat = null;
      const qn = s.match(/[（(]\s*(\d)\s*[）)]/);
      if (/記述例/.test(s)) cat = 'yosou';
      else if (qn) cat = qn[1];
      cur = cat ? { cat, heading: s, buf: [] } : null;
      continue;
    }
    if (cur) {
      if (s === '' || s.startsWith('>') || s.startsWith('---')) continue;
      cur.buf.push(s.replace(/^(\d+\.\s+|[-*]\s+)/, ''));
    }
  }
  if (cur) out.push(cur);
  return out;
}

function categoryKey(cat, format) {
  if (cat === 'yosou') return 'yosou';
  if (format === 'legacy3') return `legacy3_q${cat}`;
  if (format === 'current2') return `current2_q${cat}`;
  // format 未指定時は current2 とみなす
  return `current2_q${cat}`;
}

function severity(chars, max) {
  if (max == null) return 'nocat';
  if (chars <= max) return 'ok';
  if (chars <= Math.round(max * (1 + TOL))) return 'borderline';
  if (chars <= Math.round(max * SEVERE)) return 'over';
  return 'severe';
}

const MARK = { ok: '○', borderline: '△', over: '×', severe: '✗', nocat: '?' };
const LABEL = { ok: 'ok', borderline: 'borderline', over: '要圧縮', severe: '大幅超過', nocat: 'cat不明' };

let gateFails = 0;
const report = [];

for (const inp of inputs) {
  if (!existsSync(inp)) { console.error(`[warn] not found: ${inp}`); continue; }
  const txt = readFileSync(inp, 'utf-8');
  const { fm, body } = parseFrontmatter(txt);
  const exam = fm.exam || 'civil-1';
  const format = fm.format || 'current2';
  const table = LIMITS[exam] || LIMITS['civil-1'];
  const rows = extractAnswers(body).map((a) => {
    const key = categoryKey(a.cat, format);
    const max = table[key] ?? null;
    const chars = countChars(a.buf.join(''));
    const sev = severity(chars, max);
    if (sev === 'over' || sev === 'severe') gateFails++;
    return { key, chars, max, severity: sev, heading: a.heading };
  });
  report.push({ file: inp, exam, format, rows });
}

if (asJson) {
  console.log(JSON.stringify({ gateFails, files: report }, null, 2));
} else {
  for (const r of report) {
    console.log(`\n■ ${r.file}  [${r.exam}/${r.format}]`);
    if (r.rows.length === 0) { console.log('   (答案見出しを検出できず — ## 設問(N) 形式を確認)'); continue; }
    for (const row of r.rows) {
      const tag = row.max != null ? `${LABEL[row.severity]}(上限${row.max})` : LABEL.nocat;
      console.log(`   ${MARK[row.severity]} [${row.key.padEnd(11)}] ${String(row.chars).padStart(3)}字 ${tag}`);
    }
  }
  console.log(`\n--- 要圧縮以上 ${gateFails} 件 ---`);
}

if (strict && gateFails > 0) process.exit(1);
