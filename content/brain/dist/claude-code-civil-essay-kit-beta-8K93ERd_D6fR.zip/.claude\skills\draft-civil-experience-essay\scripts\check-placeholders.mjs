#!/usr/bin/env node
// ドラフト/レビューに未解決のプレースホルダや文字化けが残っていないか機械チェックする。
// UNKNOWN / TODO / 要確認 / 〇〇 / U+FFFD を検出する。
//
// 使い方:
//   node check-placeholders.mjs outputs/drafts/{task-id}.md [more...] [--json] [--strict]
//     --strict : 検出が1件でもあれば exit 1

import { readFileSync, existsSync } from 'node:fs';

const PATTERNS = [
  { name: 'UNKNOWN', re: /UNKNOWN/g },
  { name: 'TODO', re: /TODO/g },
  { name: '要確認', re: /要確認/g },
  { name: 'placeholder-〇', re: /〇{2,}|○{2,}/g },
  { name: 'template-年号X', re: /令和\s*[XxＸ]|平成\s*[XxＸ]/g },
  { name: 'template-brace', re: /\{[a-zA-Z][\w-]*\}/g },
  { name: 'mojibake-U+FFFD', re: /�/g },
];

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const strict = args.includes('--strict');
const inputs = args.filter((a) => !a.startsWith('--'));

if (inputs.length === 0) {
  console.error('usage: node check-placeholders.mjs <file> [more...] [--json] [--strict]');
  process.exit(2);
}

let total = 0;
const report = [];
for (const file of inputs) {
  if (!existsSync(file)) { console.error(`[warn] not found: ${file}`); continue; }
  const lines = readFileSync(file, 'utf-8').split(/\r?\n/);
  const hits = [];
  lines.forEach((line, i) => {
    for (const p of PATTERNS) {
      p.re.lastIndex = 0;
      if (p.re.test(line)) { hits.push({ line: i + 1, name: p.name, text: line.trim().slice(0, 60) }); total++; }
    }
  });
  report.push({ file, hits });
}

if (asJson) {
  console.log(JSON.stringify({ total, files: report }, null, 2));
} else {
  for (const r of report) {
    console.log(`\n■ ${r.file}`);
    if (r.hits.length === 0) { console.log('   残存なし。'); continue; }
    for (const h of r.hits) console.log(`   × L${h.line} [${h.name}] ${h.text}`);
  }
  console.log(`\n--- 残存 ${total} 件 ---`);
}

if (strict && total > 0) process.exit(1);
