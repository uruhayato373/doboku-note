---
name: draft-civil-experience-essay
description: Create and review draft experience essays for Japan's first- and second-class civil construction management examinations (1級・2級土木施工管理技士 第2次検定 施工経験記述) from a user-provided question and verified project facts. Use when Claude Code must extract requirements, build an outline, draft an experience-based answer, check length and structure, and produce a human-review report without inventing projects, roles, quantities, standards, or grading claims.
---

# 施工経験記述 設計スキル（1級・2級土木）

このスキルは、1級・2級土木施工管理技士 第2次検定「問題1 施工経験記述」の答案を、
**購入者本人が実際に経験した工事**をもとに設計・検証するための作業手順です。

Claude Code は「完成答案を代筆する道具」ではなく、
「本人の経験を、設問要求と字数制約に沿って構造化する編集パートナー」として動きます。

## 何ができるか

1. 問題文を正本として固定し、設問制約を抽出する
2. 本人の工事入力シートを読み、不足情報を `UNKNOWN` として洗い出す
3. 答案骨子（現場状況→技術的課題→検討→処置→評価の連鎖）を作る
4. Generator（civil-essay-writer）が初稿を書く
5. Evaluator（civil-essay-reviewer）が独立レビューする
6. 機械スクリプトで字数・必須項目・プレースホルダを検査する
7. 人間（購入者本人）が修正・承認する

## 絶対にやらないこと（Red Line）

- 本人が経験していない工事を答案化しない
- 工期・施工量・役割・規格値を推測で埋めない
- 問題文を創作しない（問題文は購入者が `inputs/questions/` に置いたものだけを正本とする）
- 「採点者」「添削者」「合格保証」「公式模範解答」を名乗らない・生成物に書かない
- 空欄を勝手に補完しない。`UNKNOWN` を先に提示し、必要なら答案生成を止める
- API キー・Cookie・顧客の機密情報を入力例や生成物に含めない

## 起動条件

購入者が次を用意したときに起動する。

- `inputs/questions/{name}.md` … 問題文（本人が書き写した設問。正本）
- `inputs/user-experience/project-input.md` … 工事経験入力シート（`assets/project-input.template.md` を複製して記入）
- （任意）`inputs/references/` … 本人が参照する公開資料

いずれかが欠けている場合は、不足を購入者に伝えて停止する。作業を先回りで進めない。

## 手順

### Step 1. 入力の棚卸し

1. `inputs/questions/` の問題文を読む。複数あれば「どれを対象にするか」を購入者に確認する。
2. `inputs/user-experience/project-input.md` を読む。
3. `node .claude/skills/draft-civil-experience-essay/scripts/check-required-fields.mjs inputs/user-experience/project-input.md` を実行し、必須項目の空欄・確認チェックを確認する。
4. 次のいずれかがあれば `UNKNOWN` 一覧として購入者に提示し、**推測で埋めずに停止**する。埋めるのは購入者本人。
   - 必須項目の空欄
   - **確認チェックボックスの未チェック**。特に「本人が実際に経験した工事である」「会社・顧客の機密情報を匿名化した」が未チェックのときは、起動前提が未確定のため**必ず停止**する。
   - 仮値・テンプレート残り（`令和X年`・`〇〇`・`{...}` など、記入されていない目印）。空欄ではないがまだ本人の値が入っていない状態として `UNKNOWN` 扱いにする。
   - 工事名などに「架空」「サンプル」等、実在工事か判別できない語がある場合は、実在性を購入者に確認する（本キットは本人が実際に経験した工事のみを対象とする）。

### Step 2. 級と形式のルーティング

級の正本は**入力シートの「対象級」だけ**。問題文ヘッダの級表記は参考にとどめ、単独で級を確定しない。

- 入力シートの「対象級」が `1級` → `references/civil-1.md` を読む（exam = `civil-1`）
- `2級` → `references/civil-2.md` を読む（exam = `civil-2`）
- 対象級が**空欄**、または対象級と問題文ヘッダが**食い違う**ときは、推測でルーティングせず購入者に対象級の明示を求めて停止する（字数上限が 1級200字／2級250字と実質的に異なり、誤ルーティングが答案品質へ直結するため）。
- 問題形式を判定する。
  - 設問(3)まである（技術的課題／検討／処置の3項目）→ `format: legacy3`
  - 設問(1)(2)の2テーマ形式（現行 R06〜）→ `format: current2`
  - 公式解答欄のない予想問題 → `format: yosou`

字数上限は級×形式で変わる。真実源は `scripts/check-answer-length.mjs` 内の `LIMITS` と `references/civil-1.md` / `civil-2.md`。

### Step 3. 設問制約リスト

問題文から、答案が満たすべき要求を箇条書きにする。
「何を書けと言っているか」「いくつの項目か」「字数の目安」を明示する。
`references/evidence-policy.md` に従い、根拠の有無を「根拠あり／本人未確認／推測禁止」で分類する。

### Step 4. 骨子

`references/rubric.md` の連鎖（現場状況→技術的課題→検討内容→採用処置→結果・評価）に沿って骨子を作る。
本人入力にない事実は骨子に入れない。プレースホルダが必要なら `〇〇`（全角）で置く。

### Step 5. 初稿（Generator）

`civil-essay-writer` エージェントを呼び、`assets/answer.template.md` の形式で
`outputs/drafts/{task-id}.md` に初稿を書く。

`{task-id}` は任意の短い識別子（例: `draft-001`、`kasen-hinshitsu` のような工事略称）。
購入者が指定しなければ `draft-001` を使い、以降のレビュー・承認でも同じ id を使い回す。

- frontmatter に `exam` / `format` / `status: needs-review` / `unknowns: [...]` を記録する。
- 各設問の答案本文だけを `## 設問(N) ...` 見出しの直下に置く（解説・注釈は書かない）。

### Step 6. 機械検査

初稿に対して次を実行する。

```
node .claude/skills/draft-civil-experience-essay/scripts/check-answer-length.mjs outputs/drafts/{task-id}.md
node .claude/skills/draft-civil-experience-essay/scripts/check-placeholders.mjs  outputs/drafts/{task-id}.md
```

- 字数が上限超過（要圧縮以上）→ Step 5 に戻して圧縮する。
- `UNKNOWN` / `TODO` / `要確認` / `〇〇` が残る → 購入者に確認を促す。

### Step 7. 独立レビュー（Evaluator）

`civil-essay-reviewer` エージェントを呼び、`assets/review.template.md` の形式で
`outputs/reviews/{task-id}-review.md` を書く。
Generator が書いた答案を、別の視点で `references/rubric.md` に照らして採点する。
**同じエージェントに書かせて同じエージェントに合格判定させない。**

### Step 8. 人間承認

レビュー結果を購入者に提示する。
`outputs/approved/{task-id}.md` へのコピー（承認）は**購入者本人だけ**が行う。
Claude Code は承認を代行しない。

## 状態遷移

```
draft → needs-review → needs-rework → revised → needs-review
                       └────────────→ verified → approved（本人のみ）
```

## 呼び出す references / scripts

- `references/civil-1.md` … 1級の設問形式・字数上限・要求レベル
- `references/civil-2.md` … 2級の設問形式・字数上限・要求レベル
- `references/evidence-policy.md` … 根拠分類と推測禁止の運用
- `references/rubric.md` … 答案の評価軸（連鎖・具体性・級レベル・本人整合）
- `scripts/check-required-fields.mjs` … 入力シートの必須空欄検査
- `scripts/check-answer-length.mjs` … 答案の字数検査（級×形式）
- `scripts/check-placeholders.mjs` … `UNKNOWN`/`TODO`/`〇〇`/文字化けの残存検査

## 出力形式

- 初稿: `outputs/drafts/{task-id}.md`
- レビュー: `outputs/reviews/{task-id}-review.md`
- 承認済み: `outputs/approved/{task-id}.md`（本人が手動でコピー）
