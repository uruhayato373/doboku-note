#!/usr/bin/env node
// 工事経験入力シート（project-input.md）の必須項目が空欄でないかを機械チェックする。
// 空欄は UNKNOWN として列挙する。空欄を AI が推測で埋めないための入口ゲート。
//
// 使い方:
//   node check-required-fields.mjs inputs/user-experience/project-input.md [--json] [--strict]
//     --strict : 空欄が1件でもあれば exit 1

import { readFileSync, existsSync } from 'node:fs';

// テンプレートの「- ラベル:」行を必須項目とみなす。値が空 or プレースホルダなら未記入。
const REQUIRED = [
  '対象級', '工事名', '工事場所', '工期', '発注者区分', '自分の立場', '担当業務',
  '主な工種', '施工量', '現場条件',
  '管理テーマ', '実際に発生した課題', '検討した内容', '採用した処置', '結果・評価',
];
const PLACEHOLDER = /^(〇+|○+|未定|未記入|TODO|要確認|UNKNOWN|-|—|なし)?$/i;
// 空欄ではないが本人の実値が未記入の目印（仮値・テンプレート残り）
const UNFILLED = /令和\s*[XxＸ]|平成\s*[XxＸ]|\{[a-zA-Z][\w-]*\}|〇{2,}|○{2,}/;

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const strict = args.includes('--strict');
const inputs = args.filter((a) => !a.startsWith('--'));

if (inputs.length === 0) {
  console.error('usage: node check-required-fields.mjs inputs/user-experience/project-input.md [--json] [--strict]');
  process.exit(2);
}
const file = inputs[0];
if (!existsSync(file)) { console.error(`[error] not found: ${file}`); process.exit(2); }

const txt = readFileSync(file, 'utf-8');
const values = {};
for (const line of txt.split(/\r?\n/)) {
  const m = line.match(/^\s*-\s*([^:：]+?)\s*[:：]\s*(.*)$/);
  if (m) values[m[1].trim()] = m[2].trim();
}

const missing = [];
const present = [];
for (const label of REQUIRED) {
  const v = values[label];
  if (v == null) { missing.push({ label, reason: '項目が見つからない' }); continue; }
  if (PLACEHOLDER.test(v.trim())) { missing.push({ label, reason: '空欄またはプレースホルダ' }); continue; }
  if (UNFILLED.test(v)) { missing.push({ label, reason: '仮値・テンプレート残り（実値へ置換が必要）' }); continue; }
  present.push(label);
}

// 本人経験の確認チェックボックス
const confirms = [...txt.matchAll(/^\s*-\s*\[( |x|X)\]\s*(.+)$/gm)].map((m) => ({ checked: m[1].toLowerCase() === 'x', text: m[2].trim() }));
const uncheckedConfirms = confirms.filter((c) => !c.checked);

if (asJson) {
  console.log(JSON.stringify({ missing, present, uncheckedConfirms }, null, 2));
} else {
  console.log(`\n■ ${file}`);
  console.log(`   記入済み: ${present.length}/${REQUIRED.length}`);
  if (missing.length) {
    console.log(`\n   UNKNOWN（本人が確認して埋める。AI は推測で埋めない）:`);
    for (const m of missing) console.log(`   × ${m.label} … ${m.reason}`);
  }
  if (uncheckedConfirms.length) {
    console.log(`\n   未チェックの確認項目:`);
    for (const c of uncheckedConfirms) console.log(`   □ ${c.text}`);
  }
  if (!missing.length && !uncheckedConfirms.length) console.log('   すべて記入済み・確認済み。');
}

if (strict && (missing.length || uncheckedConfirms.length)) process.exit(1);
