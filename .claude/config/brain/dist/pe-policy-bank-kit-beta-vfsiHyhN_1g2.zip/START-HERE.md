# はじめにお読みください（START-HERE）

**技術士総監の記述式（設問3）に向けて、出そうな国家課題を根拠つきで備蓄するための Claude Code 分析キット**です。

- 対象: 技術士総合技術監理部門（総監）必須科目I-2・設問3
- これは「次の的中」や「完成答案」を売る商品ではありません。出題を予言するのではなく、
  出そうな国家課題を幅広く、答案部品まで落として準備する**再現可能なワークフロー**です。

## 必要なもの

- Claude Code（CLI）
- Node.js（`node --version` で確認）
- あなたが集める一次資料（過去問・白書・政府計画。本キットには同梱しません）

## まず架空サンプルで動きを確認

```
node .claude/skills/forecast-policy-themes/scripts/validate-sources.mjs     examples/fictional-sample/source-register.yaml
node .claude/skills/forecast-policy-themes/scripts/validate-scorecards.mjs  examples/fictional-sample/theme-scorecard.yaml
node .claude/skills/forecast-policy-themes/scripts/validate-answer-length.mjs examples/fictional-sample/policy-bank-entry.md
```

## 使い方

`docs/setup-guide.md` → `docs/operation-guide.md` の順に読んでください。
実例は `docs/r8-case-study.md`（正直版）、主張の範囲は `docs/limitations-and-claims.md`。

## 大切な約束

- 「予想的中」「必ず当たる」「合格保証」とは言いません（`docs/limitations-and-claims.md`）。
- 出典のない数値・制度は書きません（Fact Checker が止めます）。
- 試験後の資料を、その年度の事前分析に混ぜません（後知恵の禁止）。
- 所属先・顧客・個人が分かる資料を AI に入力しないでください。

詳細な免責は `DISCLAIMER.txt`、ライセンスは `LICENSE.txt`。
