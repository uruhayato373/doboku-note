# 技術士総監 出題テーマ分析・国家施策バンク 生成キット（β）

Claude Code で、技術士総合技術監理部門（総監）記述式の出題候補テーマを分析し、
設問3向けの国家施策の答案部品を根拠つきで備蓄するための、非公式の分析キットです。

- 予言・完成答案・合格保証は提供しません。再現可能なワークフローを提供します。
- 詳しくは `START-HERE.md` を読んでください。

## 構成

- `.claude/skills/forecast-policy-themes/`：SKILL.md・references・scripts・templates
- `.claude/agents/`：theme-researcher / question-designer / policy-answer-writer / evaluator / fact-checker
- `examples/fictional-sample/`：架空の操作確認サンプル
- `docs/`：setup / operation / r8-case-study（正直版）/ limitations-and-claims

## 検査スクリプト

- `validate-sources.mjs`：資料台帳の欠落と後知恵混入（カットオフ以降の資料）を検出
- `validate-scorecards.mjs`：8軸0〜3・除外理由・ランキング・上位K を検査
- `validate-answer-length.mjs`：施策部品の字数（1施策≒600字）を検査

非公式ツールです。試験実施機関・Anthropic 社とは関係ありません。
