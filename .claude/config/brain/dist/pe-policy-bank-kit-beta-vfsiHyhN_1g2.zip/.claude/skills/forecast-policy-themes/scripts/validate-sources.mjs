#!/usr/bin/env node
// 資料台帳(source-register.yaml)の必須項目欠落と、カットオフ以降の資料(後知恵混入)を検出する。
// 決定論的処理。判定はここ、収集は theme-researcher、事実確認は fact-checker。
//
// 使い方:
//   node validate-sources.mjs inputs/register/source-register.yaml [--cutoff YYYY-MM-DD] [--json] [--strict]
//     --cutoff 省略時はファイル内の `cutoff:` を使う
//     --strict : 欠落 or 後知恵が1件でもあれば exit 1

import { readFileSync, existsSync } from 'node:fs';

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const strict = args.includes('--strict');
const ci = args.indexOf('--cutoff');
const cutoffArg = ci >= 0 ? args[ci + 1] : null;
const inputs = args.filter((a, i) => !a.startsWith('--') && !(ci >= 0 && i === ci + 1));

if (inputs.length === 0) { console.error('usage: node validate-sources.mjs <register.yaml> [--cutoff YYYY-MM-DD] [--json] [--strict]'); process.exit(2); }
const file = inputs[0];
if (!existsSync(file)) { console.error(`[error] not found: ${file}`); process.exit(2); }
const text = readFileSync(file, 'utf-8');

const cutoff = cutoffArg || (text.match(/^cutoff:\s*(\S+)/m)?.[1] ?? null);
const REQUIRED = ['title', 'url', 'published', 'period', 'retrieved'];
const isPlaceholder = (v) => !v || /〇|example\.(go\.jp|com)|^\.\.\.$/.test(v);
const isDate = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v);

// - id: ... で始まるブロックに分割
const lines = text.split(/\r?\n/);
const blocks = [];
let cur = null;
for (const raw of lines) {
  const m = raw.match(/^\s*-\s*id:\s*(\S+)/);
  if (m) { if (cur) blocks.push(cur); cur = { id: m[1], fields: {} }; continue; }
  if (cur) {
    const f = raw.match(/^\s*(title|url|published|period|retrieved|note):\s*(.*)$/);
    if (f) cur.fields[f[1]] = f[2].trim();
  }
}
if (cur) blocks.push(cur);

const problems = [];
for (const b of blocks) {
  for (const key of REQUIRED) {
    if (isPlaceholder(b.fields[key])) problems.push({ id: b.id, type: 'missing', field: key });
  }
  const pub = b.fields.published;
  if (isDate(pub) && cutoff && isDate(cutoff) && new Date(pub) > new Date(cutoff)) {
    problems.push({ id: b.id, type: 'hindsight', field: 'published', detail: `${pub} > cutoff ${cutoff}` });
  }
}

if (asJson) {
  console.log(JSON.stringify({ cutoff, blocks: blocks.length, problems }, null, 2));
} else {
  console.log(`\n■ ${file}  (cutoff=${cutoff ?? '未設定'}, 資料 ${blocks.length} 件)`);
  if (!cutoff) console.log('   ! cutoff 未設定。--cutoff かファイルの cutoff: を設定してください。');
  if (problems.length === 0) { console.log('   問題なし。'); }
  for (const p of problems) {
    if (p.type === 'missing') console.log(`   × [${p.id}] 欠落/未記入: ${p.field}`);
    else console.log(`   ✗ [${p.id}] 後知恵混入: ${p.detail}`);
  }
  console.log(`\n--- 問題 ${problems.length} 件（欠落${problems.filter(p=>p.type==='missing').length} / 後知恵${problems.filter(p=>p.type==='hindsight').length}）---`);
}

if (strict && problems.length > 0) process.exit(1);
