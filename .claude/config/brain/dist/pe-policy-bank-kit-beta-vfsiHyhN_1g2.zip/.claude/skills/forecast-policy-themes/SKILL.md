---
name: forecast-policy-themes
description: Analyze likely essay themes and build a bank of national-policy answer parts for Japan's Professional Engineer (Gijutsushi) comprehensive technical management (総合技術監理) written exam, from past questions, white papers, and government plans placed in local folders. Use when Claude Code must register dated sources, extract and score candidate themes on eight axes, connect them to the five management domains and their trade-offs, design likely sub-questions, draft ~600-character national-policy answer parts, verify them with an independent evaluator and fact-checker, and preserve point-in-time evidence — without fabricating sources, guaranteeing predictions, or claiming to be an examiner.
---

# 出題テーマ分析・国家施策バンク 生成スキル（技術士総監）

技術士総合技術監理部門（総監）の記述式（必須科目I-2・設問3）に向けて、
**出題を予言するのではなく、出そうな国家課題を根拠つきで幅広く備蓄する**ための作業手順です。

過去問・白書・政府基本計画を所定フォルダへ置き、Claude Code で
「資料台帳 → 候補抽出 → 8軸スコアリング → 5管理接続 → 想定設問 → 国家施策の答案部品 →
独立検証 → 証拠保存 → 試験後バックテスト」まで回します。

## 何を売るか / 売らないか

- 売る: 再現可能な**分析ワークフロー**・エージェント・テンプレート・検査スクリプト。
- 売らない: 「次の的中」「完成答案」「合格保証」「公式採点基準」。有料note本文・内部資料は同梱しない。

## 絶対にやらないこと（Red Line）

- 出典のない数値・制度・統計を答案部品に書かない（Fact Checker が止める）。
- 試験後に公表された資料を、その年度の**事前分析**へ混入させない（後知恵の禁止）。
- 「予想が的中」「必ず当たる」と表現しない。実績は「事前に候補として収録していた」まで。
- 「採点者」「添削者」「試験委員」「公式」「Anthropic認定」を名乗らない。
- 所属先・顧客・個人を識別できる資料を AI へ入力しない。
- Generator が書いた答案部品を、同じ Generator だけで合格判定しない（Evaluator を分ける）。

## 5つの管理（総監の軸・正式名）

経済性管理 / 人的資源管理 / 情報管理 / 安全管理 / 社会環境管理。
設問3の答案部品は、このうち**2つ以上のトレードオフ**を明示する。

## 手順

> [!note]
> 初回は架空サンプルで一巡を確認できる（`examples/fictional-sample/` に台帳・スコアカード・
> 施策部品の完成例がある）。本番は下記の `inputs/` に自分の資料を置く。

### Step 1. 資料台帳（source-register）

1. `inputs/sources/` に置いた過去問・白書・政府計画を読む。
2. `templates/source-register.yaml` を複製し、各資料に **url / 公表日 / 対象期間 / 取得日** を記録する。
3. **カットオフ**を決める（例: 対象年度の試験日）。試験日以降に公表された資料は事前分析から除外する。
4. `node scripts/validate-sources.mjs inputs/register/source-register.yaml --cutoff YYYY-MM-DD` で
   必須項目の欠落と、カットオフ以降の資料（後知恵混入）を検出する。1件でもあれば止めて是正する。

### Step 2. 候補テーマ抽出（theme-researcher）

`theme-researcher` エージェントを呼び、資料台帳の範囲だけから出題候補テーマを列挙する。
資料に無い最新政策を推測で足さない。

### Step 3. 8軸スコアリング（theme-scorecard）

`templates/theme-scorecard.yaml` に、各候補を8軸で0〜3採点する。

- 政策鮮度 / 国家スケール / 分野横断性 / 5管理適合性 / トレードオフ / 過去問距離 / ペルソナ展開 / 根拠充足

**上位候補数 K を先に決めて固定**する（例 K=5）。落選テーマと除外理由も必ず残す。
`node scripts/validate-scorecards.mjs inputs/scorecards/theme-scorecard.yaml` で
全軸0〜3・除外理由の有無・ランキングとKを確認する。

### Step 4. 5管理・国家スケールへの接続

各上位テーマについて、5管理のどの対立が書けるかを整理する（`references/five-management.md`）。
単一組織・単一業界に閉じるテーマは国家スケールに届かないため減点し、その旨を記録する。

### Step 5. 想定設問（question-designer）

`question-designer` エージェントで、`templates/question-spec.yaml` に設問(1)〜(3)の想定を作る。
過去問の様式（設問3=課題と施策の組合せ2つ・各答案用紙1枚≒600字・5管理2つ以上のトレードオフ明記）
に合わせる。問題文を「公式のもの」と偽らない（あくまで想定）。

### Step 6. 国家施策の答案部品（policy-answer-writer）

`policy-answer-writer` エージェントで、`templates/policy-bank-entry.md` に沿って施策部品を作る。
各施策は ①課題と施策 ②有効性と実現性 ③障害と克服策（5管理2つ以上のトレードオフ）で構成し、
**1施策 ≒ 600字以内**に収める。「5管理2つ以上」は1施策の③内に対立を複数組書いてもよいし、
2施策で別々の対立を書いてもよい。制度・統計には基準日と出典を付ける。
生成物は `outputs/policy-bank/<theme>.md` に置く（検査スクリプトの対象）。

### Step 7. 独立検証（evaluator + fact-checker）

- `evaluator`: 論点の妥当性・5管理接続・国家スケール・設問要求適合を採点する（audit-only）。
- `fact-checker`: 数値・制度名・統計に出典があるか、古い制度を使っていないかを検証する。
  出典不明は「要出典」で止める。

### Step 8. 証拠保存とバックテスト

- 生成物・スコアカード・想定設問・答案部品を `outputs/` にファイルで残す。
- 公開する場合は**公開日を記録**（将来の前向き検証＝pre-registration の証拠になる）。
- 試験後は `templates/post-exam-review.md` で、実際の出題と上位K候補を照合し、
  一致/部分一致/不一致・カバレッジ・外れ候補・見逃しを記録する（的中率だけを見せない）。

## 機械検査（scripts）

```
node scripts/validate-sources.mjs      inputs/register/source-register.yaml --cutoff YYYY-MM-DD
node scripts/validate-scorecards.mjs   inputs/scorecards/theme-scorecard.yaml
node scripts/validate-answer-length.mjs outputs/policy-bank/*.md
```

## 呼び出す references / agents / templates

- references: `five-management.md`（5管理とトレードオフ）、`scoring-rubric.md`（8軸の採点基準）、
  `claims-policy.md`（実績表現・出典・後知恵禁止）
- agents: theme-researcher / question-designer / policy-answer-writer / evaluator / fact-checker
- templates: source-register / theme-scorecard / question-spec / policy-bank-entry / post-exam-review

## 出力

- `outputs/register/` 資料台帳 / `outputs/scorecards/` スコアカード /
  `outputs/questions/` 想定設問 / `outputs/policy-bank/` 施策部品 / `outputs/reviews/` 検証・振り返り
