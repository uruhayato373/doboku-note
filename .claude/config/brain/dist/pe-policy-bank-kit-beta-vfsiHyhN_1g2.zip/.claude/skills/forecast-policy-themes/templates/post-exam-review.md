# 試験後バックテスト（post-exam-review）
# 実際の出題と、事前に固定した上位K候補を照合する。的中率だけを見せない。

year: 令和X年度
exam_date: YYYY-MM-DD
actual_theme: （実際のI-2記述式テーマ）

pre_registered:
  K: 5                       # 事前に固定していた上位候補数（後知恵で縮めない）
  fixed_at: YYYY-MM-DD       # 候補を固定した日（公開日など＝前向き検証の証拠）
  candidates: [テーマ1, テーマ2, テーマ3, テーマ4, テーマ5]

judgment:
  layer1_theme: 一致 / 部分一致 / 不一致     # 論点一致で判定。理由を下に書く
  layer1_reason: （なぜその区分か）
  layer2_parts: 直接使用可 / 要改変 / 使用不可  # 施策部品が設問要求に合うか
  coverage: （上位K候補が実出題を含んだか）
  missed: （上位に入れられず出題されたテーマ・あれば）
  false_candidates: （上位に挙げたが出題されなかったテーマと理由）

blindness:
  method: A(LLMブラインド) / B(事前登録) / C(第三者採点)
  note: 実行者が答えを知る遡及はC推奨。前向き公開はBが成立。

improvement: （次年度へ戻す気づき・重み調整）
