#!/usr/bin/env node
// テーマスコアカード(theme-scorecard.yaml)を検査する。全8軸が0〜3か、落選テーマに除外理由があるか、
// ランキングと上位K を表示する。判定はここ、採点は人/エージェント。
//
// 使い方:
//   node validate-scorecards.mjs inputs/scorecards/theme-scorecard.yaml [--json] [--strict]
//     --strict : 軸の欠落/範囲外 or 除外理由なしが1件でもあれば exit 1

import { readFileSync, existsSync } from 'node:fs';

const AXES = ['policy_freshness','national_scale','cross_domain','five_mgmt_fit','tradeoff','pastq_distance','persona_span','evidence'];

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const strict = args.includes('--strict');
const inputs = args.filter((a) => !a.startsWith('--'));
if (inputs.length === 0) { console.error('usage: node validate-scorecards.mjs <scorecard.yaml> [--json] [--strict]'); process.exit(2); }
const file = inputs[0];
if (!existsSync(file)) { console.error(`[error] not found: ${file}`); process.exit(2); }
const text = readFileSync(file, 'utf-8');

const K = parseInt(text.match(/^K:\s*(\d+)/m)?.[1] ?? '0', 10);

// - id: でブロック分割
const lines = text.split(/\r?\n/);
const blocks = [];
let cur = null;
for (const raw of lines) {
  const m = raw.match(/^\s*-\s*id:\s*(\S+)/);
  if (m) { if (cur) blocks.push(cur); cur = { id: m[1], name: '', scores: {}, excluded: false, exclude_reason: '' }; continue; }
  if (!cur) continue;
  const nm = raw.match(/^\s*name:\s*(.*)$/); if (nm) cur.name = nm[1].trim();
  const ex = raw.match(/^\s*excluded:\s*(true|false)/); if (ex) cur.excluded = ex[1] === 'true';
  const er = raw.match(/^\s*exclude_reason:\s*(.*)$/); if (er) cur.exclude_reason = er[1].trim();
  const sc = raw.match(/^\s*(policy_freshness|national_scale|cross_domain|five_mgmt_fit|tradeoff|pastq_distance|persona_span|evidence):\s*(-?\d+)/);
  if (sc) cur.scores[sc[1]] = parseInt(sc[2], 10);
}
if (cur) blocks.push(cur);

const problems = [];
for (const b of blocks) {
  for (const ax of AXES) {
    const v = b.scores[ax];
    if (v == null) problems.push({ id: b.id, msg: `軸欠落: ${ax}` });
    else if (v < 0 || v > 3) problems.push({ id: b.id, msg: `範囲外(0-3): ${ax}=${v}` });
  }
  if (b.excluded && !b.exclude_reason) problems.push({ id: b.id, msg: '落選なのに除外理由なし' });
  b.total = AXES.reduce((s, ax) => s + (b.scores[ax] ?? 0), 0);
}

const ranked = blocks.filter(b => !b.excluded).sort((a, b) => b.total - a.total);

if (asJson) {
  console.log(JSON.stringify({ K, count: blocks.length, ranked: ranked.map(b => ({ id: b.id, name: b.name, total: b.total })), problems }, null, 2));
} else {
  console.log(`\n■ ${file}  (K=${K}, テーマ ${blocks.length} 件)`);
  console.log('  ランキング(非落選):');
  ranked.forEach((b, i) => {
    const inK = i < K ? '★' : ' ';
    console.log(`   ${inK} ${String(b.total).padStart(2)}/24  ${b.id} ${b.name}`);
  });
  const excluded = blocks.filter(b => b.excluded);
  if (excluded.length) { console.log('  落選:'); for (const b of excluded) console.log(`     ${b.id} ${b.name} — ${b.exclude_reason || '(理由未記入)'}`); }
  if (problems.length) { console.log('  問題:'); for (const p of problems) console.log(`   × [${p.id}] ${p.msg}`); }
  else console.log('  問題なし。');
  if (K > 0 && ranked.length < K) console.log(`  ! 非落選テーマ ${ranked.length} < K=${K}。候補が足りません。`);
}

if (strict && problems.length > 0) process.exit(1);
