#!/usr/bin/env node
// 国家施策バンクの施策部品の字数を検査する。設問3の1施策 ≒ 答案用紙1枚(約600字)。
// 「## 施策N：...」見出し直下から次見出しまでを1施策として字数を数える。
//
// 使い方:
//   node validate-answer-length.mjs outputs/policy-bank/<theme>.md [more...] [--json] [--strict]
//     --strict : 要圧縮(over)以上が1件でもあれば exit 1

import { readFileSync, existsSync } from 'node:fs';

const MAX = 600;      // 答案用紙1枚 ≒ 600字
const TOL = 0.1;      // +10% は borderline
const SEVERE = 1.3;   // ×1.3超は大幅超過

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const strict = args.includes('--strict');
const inputs = args.filter((a) => !a.startsWith('--'));
if (inputs.length === 0) { console.error('usage: node validate-answer-length.mjs <policy-bank.md> [more...] [--json] [--strict]'); process.exit(2); }

// 装飾・タグ・空白を除いた実文字数（プレースホルダ 〇 は算入）
function countChars(s) {
  return [...s.replace(/<[^>]+>/g, '').replace(/[`*]/g, '').replace(/\s/g, '')].length;
}
function severity(n) {
  if (n <= MAX) return 'ok';
  if (n <= Math.round(MAX * (1 + TOL))) return 'borderline';
  if (n <= Math.round(MAX * SEVERE)) return 'over';
  return 'severe';
}
const MARK = { ok: '○', borderline: '△', over: '×', severe: '✗' };
const LABEL = { ok: 'ok', borderline: 'borderline', over: '要圧縮', severe: '大幅超過' };

// 「## 施策N：...」を1施策の区切りとみなす
function extract(body) {
  const lines = body.split(/\r?\n/);
  const out = [];
  let cur = null;
  for (const raw of lines) {
    const s = raw.trim();
    if (/^#{1,4}\s*施策/.test(s)) { if (cur) out.push(cur); cur = { heading: s, buf: [] }; continue; }
    if (/^#{1,4}\s/.test(s)) { if (cur) { out.push(cur); cur = null; } continue; } // 別見出しで打ち切り
    if (cur) { if (s === '' || s.startsWith('>')) continue; cur.buf.push(s); }
  }
  if (cur) out.push(cur);
  return out;
}

let gateFails = 0;
const report = [];
for (const f of inputs) {
  if (!existsSync(f)) { console.error(`[warn] not found: ${f}`); continue; }
  const rows = extract(readFileSync(f, 'utf-8')).map((a) => {
    const chars = countChars(a.buf.join(''));
    const sev = severity(chars);
    if (sev === 'over' || sev === 'severe') gateFails++;
    return { heading: a.heading, chars, severity: sev };
  });
  report.push({ file: f, rows });
}

if (asJson) {
  console.log(JSON.stringify({ max: MAX, gateFails, files: report }, null, 2));
} else {
  for (const r of report) {
    console.log(`\n■ ${r.file}`);
    if (r.rows.length === 0) { console.log('   (施策見出し ## 施策N を検出できず)'); continue; }
    for (const row of r.rows) console.log(`   ${MARK[row.severity]} ${String(row.chars).padStart(3)}字 ${LABEL[row.severity]}(上限${MAX})  ${row.heading.slice(0, 28)}`);
  }
  console.log(`\n--- 要圧縮以上 ${gateFails} 件 ---`);
}
if (strict && gateFails > 0) process.exit(1);
