# 操作ガイド（ワークフロー）

スキルは次の順で進みます（`SKILL.md` の Step と対応）。

1. **資料台帳**：試験日前資料だけを登録。`validate-sources.mjs --cutoff <試験日>` で後知恵混入・欠落を検出。
2. **候補抽出**（theme-researcher）：台帳の範囲だけからテーマを列挙。
3. **8軸スコアリング**：`theme-scorecard.yaml` に0〜3で採点。**Kを先に固定**、落選理由も残す。`validate-scorecards.mjs`。
4. **5管理接続**：各上位テーマの管理対立を整理（`references/five-management.md`）。
5. **想定設問**（question-designer）：過去問様式で `question-spec.yaml`。公式問題と偽らない。
6. **施策部品**（policy-answer-writer）：`policy-bank-entry.md` に①②③構成・1施策約600字。`validate-answer-length.mjs`。
7. **独立検証**：evaluator（論点・5管理・国家スケール）＋ fact-checker（出典・後知恵）。
8. **証拠保存＋バックテスト**：公開日を記録（前向き検証の証拠）。試験後は `post-exam-review.md` で照合。

## 大事な運用ルール

- 「予想的中」と書かない。実績は「候補として事前収録していた（公開日で確認可）」まで。
- K・カバレッジ・外れ候補・見逃しをセットで開示する（的中率だけを見せない）。
- 出典のない数値・制度は書かない。制度・統計には基準日と出典を付ける。
- 過年度の遡及検証は、答えを知っている状態での採点を避ける（第三者採点 or 事前登録）。
