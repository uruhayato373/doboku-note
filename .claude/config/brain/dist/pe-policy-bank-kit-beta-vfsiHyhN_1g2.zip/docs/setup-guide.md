# セットアップガイド

## 必要なもの

- Claude Code（CLI）が使える環境
- Node.js（検査スクリプト実行用。`node --version` で確認）
- 過去問・白書・政府計画などの**一次資料**（あなたが集める。本キットには同梱しない）

## フォルダ構成

```
pe-policy-forecast-kit/
├── START-HERE.md
├── .claude/
│   ├── skills/forecast-policy-themes/   （SKILL.md・references・scripts・templates）
│   └── agents/                          （theme-researcher 他 5体）
├── inputs/    （あなたが置く: sources / register / scorecards）
├── outputs/   （生成物: register / scorecards / questions / policy-bank / reviews）
├── examples/fictional-sample/           （架空の操作確認サンプル）
└── docs/
```

## 最初の一巡（架空サンプルで確認）

```
node .claude/skills/forecast-policy-themes/scripts/validate-sources.mjs     examples/fictional-sample/source-register.yaml
node .claude/skills/forecast-policy-themes/scripts/validate-scorecards.mjs  examples/fictional-sample/theme-scorecard.yaml
node .claude/skills/forecast-policy-themes/scripts/validate-answer-length.mjs examples/fictional-sample/policy-bank-entry.md
```

いずれも問題なし（緑）で表示されれば準備完了です。

## 本番の始め方

1. `inputs/sources/` に一次資料を置く。
2. `templates/source-register.yaml` を複製して `inputs/register/source-register.yaml` に資料を登録。
3. Claude Code で「総監の出題テーマを分析して施策バンクを作って」と伝える。スキルが起動します。
